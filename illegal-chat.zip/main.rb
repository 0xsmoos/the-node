require 'tk'

root = TkRoot.new { title "Hello, World!" }
TkLabel.new(root) do
   text 'Hello, World!'
   pack { padx 15 ; pady 15; side 'left' }
end
Tk.mainloop


require "tk"

button = TkButton.new {
   text 'Hello World!'
   pack
}
button.configure('activebackground', 'blue')
Tk.mainloop

color = button.cget('activebackground')

color = button.configure('activebackground')

helpButton = TkButton.new(buttonFrame) {
   text "Help"
   command { showHelp }
}